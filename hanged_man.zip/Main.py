import random

def pick_random_word():
    word = ""
    while(len(word) < 5):
        word = random.choice(open("sowpods.txt").read().split()).strip()
    return word

def place(word, x, guess):
    for t in range(len(word)):
        if(word[0] == guess.upper()):
            x[0] = guess.upper()
        if(guess == word[t]):
            x[t] = guess

def game():
    print('Welcome to Hangman')
    max_guesses = int(input("How many false guesses do you have? "))
    word = pick_random_word()
    word = word.lower().capitalize()

    x = []
    for i in word:
        x.append('_')
    print(x)

    i = 0
    while(i < max_guesses):
        guess = input("Guess the letter: ")
        if(guess.upper() not in word.upper()):
            i += 1
            print("Incorrect! You have ", max_guesses - i, " more tries")
        else:
            place(word, x, guess)
            if(x[0] != '_'):
                x[0].upper()
        print(x)
        if('_' not in x):
            print('Congratulations! You won!')
            break

game()